import json
import pandas as pd
from pathlib import Path
import os
import psycopg2
import time 
import torch
import torch.nn as nn 
import numpy as np 
import matplotlib.pyplot as plt


class LSTMModel(nn.Module): 
    def __init__(self, input_dim, hidden_dim, layer_dim, output_dim):
        super(LSTMModel, self).__init__()
        self.hidden_dim = hidden_dim
        self.layer_dim = layer_dim
        self.lstm = nn.LSTM(input_dim, hidden_dim, layer_dim, batch_first=True)
        self.fc = nn.Linear(self.hidden_dim, output_dim)
    def forward(self, x, h0=None, c0=None): 
        batch_size = x.size(0)
        if (
            h0 is None
            or c0 is None
            or h0.size(1) != batch_size
            or c0.size(1) != batch_size
        ):
            h0 = torch.zeros(self.layer_dim, x.size(0), self.hidden_dim).to(x.device)
            c0 = torch.zeros(self.layer_dim, x.size(0), self.hidden_dim).to(x.device)
        out, (hn, cn) = self.lstm(x, (h0,c0))
        out = self.fc(out[:, -1, :])
        return out, hn ,cn 

def  main(): 
    X_test = np.loadtxt('01_a_test_data.txt')
    y_test = np.loadtxt('01_a_test_label.txt', dtype='int64')

    #データの合成あり
    X_train_a = np.loadtxt('01_a_train_data.txt')
    y_train_a = np.loadtxt('01_a_train_label.txt', dtype='int64')
    
    X_test_a = np.loadtxt('01_a_test_data.txt')
    y_test_a = np.loadtxt('01_a_test_label.txt', dtype='int64')
    
    X_train_c = np.loadtxt('01_c_train_data.txt')
    y_train_c = np.loadtxt('01_c_train_label.txt', dtype='int64')
    
    X_test_c = np.loadtxt('01_c_test_data.txt')
    y_test_c = np.loadtxt('01_c_test_label.txt', dtype='int64')
    
    X_train = np.concatenate([X_train_a, X_train_c])
    y_train = np.concatenate([y_train_a, y_train_c])
    print(len(y_train))

    X_train = torch.tensor(X_train, dtype=torch.float32).unsqueeze(-1)
    y_train = torch.tensor(y_train, dtype=torch.float32).view(-1, 1)
    X_test = torch.tensor(X_test, dtype=torch.float32).unsqueeze(-1)

    model = LSTMModel(input_dim=X_train.size(2), hidden_dim=100, layer_dim=1, output_dim=1)
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
    num_epochs = 500 
    h0, c0 = None, None
    for epcho in range(num_epochs): 
        model.train()
        optimizer.zero_grad()
        outputs, h0, c0 = model(X_train, h0, c0)
        loss = criterion(outputs, y_train)
        loss.backward()
        optimizer.step()
        h0, c0 = h0.detach(), c0.detach()
        if(epcho + 1 ) % 100 == 0:
                print(f'Epoch [{epcho+1}/{num_epochs}], Loss: {loss.item():.4f}')
        model.eval()       
    with torch.no_grad():
        predicted, _, _ = model(X_test)
        print(predicted)
if __name__ == '__main__':
    main()